# Hand Control Pro 4.0 — کنترل کامپیوتر با ژست دست

## اجرا
**ویندوز:** پایتون 3.12 + `pip install numpy==1.26.4 mediapipe==0.10.21 pyautogui PyQt6` سپس `python hand_control_pro.py`
(اختیاری: `install_extras.bat` برای صدا، ماکرو، MQTT، OBS) — ساخت exe: `build_exe.bat` ؛ نصب‌کننده: `installer.iss`
**لینوکس (X11):** `bash install_linux.sh` سپس `./run_linux.sh`

## ساختار
| مسیر | کار |
|---|---|
| `hand_control_pro.py` | برنامهٔ اصلی (رابط، موتور تشخیص، ژست‌ها، عمل‌ها) |
| `hcx/learn.py` | یادگیری ژست از نمونه‌های کاربر (نزدیک‌ترین‌همسایه + افزایش داده) |
| `hcx/headtrack.py` | کنترل با سر و پلک |
| `hcx/overlay.py` | لیزر، نقاشی، نورافکن، زمان‌سنج روی صفحه + کیبورد هوایی |
| `hcx/voice.py` | دستور صوتی آفلاین (Vosk) |
| `hcx/integrations.py` | Home Assistant، MQTT، Hue، OBS، صدای راهنما |
| `hcx/macro.py` | ضبط ماکرو (ماوس و صفحه‌کلید) |
| `hcx/plugins.py` | افزونه‌ها (پوشهٔ `~/.hand_control/plugins`) |
| `hcx/remote.py` | کنترل از مرورگر گوشی (PIN) |
| `hcx/stats.py`, `hcx/updater.py`, `hcx/i18n.py` | آمار و یادآور استراحت، بررسی نسخه، زبان |
| `tests/` | ۶۱ تست خودکار: `run_tests.sh` یا `run_tests.bat` |

## تست
`python3 -m unittest discover -s tests -t .` — فقط numpy لازم است (دوربین، MediaPipe و Qt شبیه‌سازی می‌شوند).
تست‌ها منطق را می‌سنجند؛ رفتار واقعی روی دوربین، صفحه‌نمایش و سرویس‌های بیرونی را باید خودتان امتحان کنید.

## داده‌ها
پوشهٔ `~/.hand_control`: `config.json` (تنظیمات)، `stats.json` (آمار)، `plugins/`، `lang/<کد>.json` (ترجمه‌ها)
